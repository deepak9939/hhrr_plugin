export default function (server) {
  return server.config().get('hhrr.local.groups');
}
